Use WSAD to move.
Use the Left Mouse Button to interact with things and use items.
Hold Q to select an item.
Press Right Mouse Button to throw away an item.
Press P to reset the game.